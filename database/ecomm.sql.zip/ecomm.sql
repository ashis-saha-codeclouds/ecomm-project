-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 08, 2023 at 05:36 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecomm`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(55) NOT NULL,
  `email_id` varchar(155) NOT NULL,
  `password` varchar(55) NOT NULL,
  `name` varchar(50) NOT NULL,
  `role` varchar(50) NOT NULL,
  `last_login` datetime NOT NULL DEFAULT current_timestamp(),
  `status` char(1) NOT NULL COMMENT '0: Inactive\r\n1: Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `username`, `email_id`, `password`, `name`, `role`, `last_login`, `status`) VALUES
(1, 'admin', 'ashish.saha@codeclouds.com', '68a24878cc568766b735c62be5f306ed', 'Ashiss Sahaa', 'admin', '0000-00-00 00:00:00', '1');

-- --------------------------------------------------------

--
-- Table structure for table `banner`
--

CREATE TABLE `banner` (
  `banner_id` int(11) NOT NULL,
  `banner_title` varchar(100) NOT NULL,
  `banner_image` varchar(255) NOT NULL,
  `banner_status` char(1) NOT NULL DEFAULT '0' COMMENT '2=Inactive\r\n1=Active/Published',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `is_deleted` char(1) NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `banner`
--

INSERT INTO `banner` (`banner_id`, `banner_title`, `banner_image`, `banner_status`, `created_at`, `updated_at`, `is_deleted`) VALUES
(7, 'Banner-1', '1691145873-5056179b42b174f.jpg', '1', '2023-08-04 16:14:33', '2023-08-04 16:14:33', 'N'),
(8, 'Banner-2', '1691145979-kisspng-e-commerce-logo-electronic-business-5b00d2d0918d84.2335269315267806245962.jpg', '1', '2023-08-04 16:16:19', '2023-08-04 16:16:19', 'N'),
(9, 'Banner-3', '1691146231-no-image.jpg', '2', '2023-08-04 16:20:31', '2023-08-04 16:20:31', 'N'),
(10, 'Banner5', '1691436182-5056179b42b174f.jpg', '2', '2023-08-08 00:53:02', '2023-08-08 00:53:02', 'N');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(11) NOT NULL,
  `cat_title` varchar(155) NOT NULL,
  `cat_status` char(1) NOT NULL DEFAULT '1' COMMENT '1=Active\r\n2=In Active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `is_deleted` char(1) NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`, `cat_status`, `created_at`, `is_deleted`) VALUES
(23, 'Cat-1', '1', '2023-07-27 00:23:31', 'Y'),
(24, 'Cat-2', '2', '2023-07-27 00:23:40', 'N'),
(25, 'Cat-4', '1', '2023-07-27 00:51:41', 'N'),
(26, 'Cat-5', '1', '2023-07-27 00:55:57', 'N'),
(27, 'Cat-7', '1', '2023-07-27 00:59:06', 'N'),
(28, 'Cay-8', '1', '2023-08-02 00:59:39', 'N'),
(29, 'cattest2', '1', '2023-08-08 00:56:34', 'N');

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `opt_id` int(11) NOT NULL,
  `site_name` varchar(100) NOT NULL,
  `site_title` varchar(50) NOT NULL,
  `site_desc` varchar(255) NOT NULL,
  `site_logo` varchar(155) NOT NULL,
  `site_address` varchar(255) NOT NULL,
  `site_contact` varchar(50) NOT NULL,
  `site_email` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`opt_id`, `site_name`, `site_title`, `site_desc`, `site_logo`, `site_address`, `site_contact`, `site_email`) VALUES
(1, 'Ecommerce Project', 'Ecommerce Project', 'Ecommerce Project Description', '1690301769-kisspng-e-commerce-logo-electronic-business-5b00d2d0918d84.2335269315267806245962.jpg', '#1212, E-comm Project2 Description', '9876543215', 'support@ecomm.comm');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` varchar(100) NOT NULL,
  `product_qty` varchar(100) NOT NULL,
  `total_amount` varchar(10) NOT NULL,
  `order_date` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_on` datetime NOT NULL DEFAULT current_timestamp(),
  `order_status` char(1) NOT NULL DEFAULT '1' COMMENT '1=Confirm\r\n2=Cancelled',
  `is_deliver` char(1) NOT NULL DEFAULT '3' COMMENT '1=Delivered/Shippied\r\n2=Deliver In Process\r\n3=Not Delivered\r\n',
  `deleted` char(1) NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `product_id`, `product_qty`, `total_amount`, `order_date`, `updated_on`, `order_status`, `is_deliver`, `deleted`) VALUES
(1, 1, '2', '2', '200', '2023-08-08 10:48:46', '2023-08-08 10:48:46', '1', '3', 'N'),
(5, 1, '1,2,3', '1,1,1', '300', '2023-08-08 10:48:46', '2023-08-08 10:48:46', '1', '2', 'N'),
(6, 2, '1,2,4', '2,1,5', '350', '2023-08-08 10:48:46', '2023-08-08 10:48:46', '1', '2', 'N'),
(7, 1, '2,4', '2,5', '250', '2023-08-08 10:48:46', '2023-08-08 10:48:46', '1', '3', 'N');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_title` varchar(255) NOT NULL,
  `product_sku` varchar(100) NOT NULL,
  `product_price` varchar(100) NOT NULL,
  `product_description` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL DEFAULT 1,
  `product_image` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `Updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `product_status` char(1) NOT NULL DEFAULT '1' COMMENT '3=Inactive\r\n1=Active\r\n2=Draft',
  `is_featured` char(1) NOT NULL DEFAULT '2' COMMENT '2=No\r\n1=Yes',
  `is_deleted` char(1) NOT NULL DEFAULT 'N' COMMENT 'N=No\r\nY=Yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_title`, `product_sku`, `product_price`, `product_description`, `category_id`, `product_image`, `created_at`, `Updated_at`, `product_status`, `is_featured`, `is_deleted`) VALUES
(1, 'Test Product.....', 'test0100', '100', 'Test.............', 26, '1691414359-5056179b42b174f.jpg', '2023-08-06 14:19:14', '2023-08-06 14:19:14', '2', '1', 'N'),
(2, 'Test Product01m', 'test010000', '100', 'this is a test product.........', 27, '1691415485-5056179b42b174f.jpg', '2023-08-07 19:08:05', '2023-08-07 19:08:05', '1', '2', 'N'),
(3, 'Test Product011', 'test0100ABC', '100', 'This is a Test Product......', 26, '1691416069-no-image.jpg', '2023-08-07 19:17:49', '2023-08-07 19:17:49', '3', '2', 'N'),
(4, 'Test Product023', 'Product023', '10', 'Test Product', 25, '1691435337-no-image.jpg', '2023-08-08 00:38:57', '2023-08-08 00:38:57', '2', '1', 'N');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `user_fname` varchar(50) NOT NULL,
  `user_lname` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` char(15) NOT NULL,
  `password` varchar(55) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(55) NOT NULL,
  `created_on` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_on` datetime NOT NULL DEFAULT current_timestamp(),
  `user_status` char(1) NOT NULL DEFAULT 'Y' COMMENT 'Y=Active\r\nN= InActive',
  `user_del` char(1) NOT NULL DEFAULT 'N' COMMENT 'N=No\r\nY=Yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_fname`, `user_lname`, `username`, `email`, `mobile`, `password`, `address`, `city`, `created_on`, `updated_on`, `user_status`, `user_del`) VALUES
(1, 'Test1', 'Test1', 'test1@test.com', 'test1@test.com', '9876543210', '68a24878cc568766b735c62be5f306ed', 'Test Address', 'Kolkata', '2023-08-08 10:43:47', '2023-08-08 10:43:47', 'Y', 'N'),
(2, 'Test2', 'Test2', 'test2@test.com', 'test2@test.com', '9876543211', '68a24878cc568766b735c62be5f306ed', 'Test Address of Test2 user', 'North 24 Pgns', '2023-08-08 10:43:47', '2023-08-08 10:43:47', 'Y', 'N');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `banner`
--
ALTER TABLE `banner`
  ADD PRIMARY KEY (`banner_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`opt_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `user_id_2` (`user_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `user_id_3` (`user_id`),
  ADD KEY `user_id` (`user_id`) USING BTREE,
  ADD KEY `product_id_2` (`product_id`) USING BTREE;

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `product_sku` (`product_sku`),
  ADD KEY `product_name` (`product_title`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `email` (`email`),
  ADD KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `banner`
--
ALTER TABLE `banner`
  MODIFY `banner_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `options`
--
ALTER TABLE `options`
  MODIFY `opt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
